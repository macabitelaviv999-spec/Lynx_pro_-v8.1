# LYNX PRO v8.1 — פריסה אוטומטית בענן (GitHub ⟵ Vercel)

הפרויקט בנוי ללא תלויות חיצוניות (Zero Dependencies) כך שההידור, אימות התקינות, החתמת ה-Service Worker והפריסה מתבצעים **100% אוטומטית בענן של Vercel** — ללא צורך בכלים מקומיים.

## העלאה ל-GitHub וחיבור אוטומטי ל-Vercel (דרך הדפדפן בלבד)

### שלב 1: העלאה למאגר GitHub
1. היכנס ל-GitHub וצור מאגר חדש (למשל `lynx-pro`).
2. חלץ את קובץ ה-ZIP, לחץ במאגר על **Add file ⟵ Upload files**, וגרור את כל תוכן התיקייה (`api/`, `public/`, `scripts/`, `.github/`, `vercel.json`, `package.json`, `README.md`, `.gitignore`, `.vercelignore`, `.env.example`).
3. לחץ **Commit changes** לענף `main`.

### שלב 2: ייצוא ובנייה אוטומטית ב-Vercel
1. היכנס ל-Vercel עם חשבון ה-GitHub שלך ולחץ **Add New ⟵ Project**.
2. בחר במאגר `lynx-pro` ולחץ **Import**.
3. `vercel.json` מגדיר אוטומטית את `npm run build`, את תיקיית הפלט `public` ואת פונקציות ה-Serverless תחת `api/`.
4. לחץ **Deploy** — מעתה כל שינוי ב-GitHub עובר אימות, חותם גרסת Service Worker חדשה ונפרס אוטומטית בענן.

### שלב 3 (אופציונלי): חיבור KV וסודות Zero-Trust ב-Vercel
- **קיצור קישורים `/s/:code` וסנכרון `/api/sync`:** בתפריט הפרויקט ב-Vercel היכנס ל-**Storage ⟵ Create Database ⟵ Upstash Redis (KV)** וחבר לפרויקט (Vercel יזריק אוטומטית `KV_REST_API_URL` ו-`KV_REST_API_TOKEN`).
- **ספק SMS / Webhook:** תחת **Settings ⟵ Environment Variables** הוסף `UPSTREAM_WEBHOOK_URL` ו-`UPSTREAM_BEARER_TOKEN`.
