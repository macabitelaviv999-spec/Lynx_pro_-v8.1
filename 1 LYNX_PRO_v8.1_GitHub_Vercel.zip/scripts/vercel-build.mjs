import fs from "node:fs";
import path from "node:path";

const checkOnly = process.argv.includes("--check-only");
const pubDir = path.resolve("public");

const requiredFiles = [
  "index.html",
  "master.html",
  "lynx-reset-layout.css",
  "lynx-core.js",
  "optical-canvas-engine.js",
  "sw.js",
  "manifest.json",
  "updates.json",
  "icon-192.png",
  "icon-512.png",
  "preview.jpg"
];

for (const rel of requiredFiles) {
  const fp = path.join(pubDir, rel);
  if (!fs.existsSync(fp)) {
    throw new Error(`Missing required public asset: ${rel}`);
  }
}

for (const jf of ["manifest.json", "updates.json"]) {
  JSON.parse(fs.readFileSync(path.join(pubDir, jf), "utf8"));
}

if (!checkOnly) {
  const buildHash = (
    process.env.VERCEL_GIT_COMMIT_SHA ||
    process.env.GITHUB_SHA ||
    Date.now().toString(36)
  ).slice(0, 7);

  const swPath = path.join(pubDir, "sw.js");
  const swSrc = fs.readFileSync(swPath, "utf8");
  const stamped = swSrc.replace(/lynx-pro-v8-1-[A-Za-z0-9_-]+/, `lynx-pro-v8-1-${buildHash}`);
  fs.writeFileSync(swPath, stamped, "utf8");
  console.log(`[LYNX Vercel Cloud Build] Validated ${requiredFiles.length} assets & stamped SW cache: lynx-pro-v8-1-${buildHash}`);
} else {
  console.log(`[LYNX CI Check] All ${requiredFiles.length} required public assets and JSON manifests are valid.`);
}
