/* LYNX PRO v8.0 — Shared Offline-First Core (Vercel Cloud Autonomous Sync)
 * - Rule 1: IndexedDB + SHA-256 Salted PIN Hashing + Cryptographic Payload Signatures
 * - Rule 2: Optimistic UI + Strict FIFO Sync Queue -> Cloudflare Worker (/api/sync & /api/dispatch)
 * - Rule 3: Deep Navigation via History API
 * - Rule 6: Controlled Technician Maintenance Logs
 * - Rule 8: Creative Multi-Language Layer (HE / EN / AR / RU)
 * - Rule 9: Zero external Drive dependency — Vercel Serverless + KV is the cloud source of truth
 */
(function (global) {
  "use strict";

  const SCHEMA_VER = "8.1";
  const DEFAULT_WORKER = (typeof location !== "undefined" && (location.protocol === "http:" || location.protocol === "https:")) ? location.origin : "https://lynx-pro.vercel.app";
  const LRM = "\u200E";
  const RLM = "\u200F";
  const CAT_KEYS = ["auto", "zimmer", "attraction", "lab", "food", "beauty", "general"];

  const CAT_META = {
    auto:       { side: "IL", he: "מספר רכב",       en: "Plate #",   ar: "رقم اللوحة",  ru: "Номер авто", ph: "48-219-01", flow: "exit" },
    zimmer:     { side: "🔑", he: "חדר / סוויטה",   en: "Suite #",   ar: "رقم الجناح",  ru: "Номер люкс", ph: "סוויטה 04", flow: "entry" },
    attraction: { side: "🎟️", he: "מספר אישור",     en: "Ticket #",  ar: "رقم التذكرة", ru: "Билет #",    ph: "אישור #482", flow: "entry" },
    lab:        { side: "🔧", he: "מספר תיקון",     en: "Repair #",  ar: "رقم الصيانة", ru: "Ремонт #",   ph: "תיקון #104", flow: "exit" },
    food:       { side: "🍽️", he: "מספר הזמנה",     en: "Order #",   ar: "رقم الطلب",   ru: "Заказ #",    ph: "הזמנה #084", flow: "exit" },
    beauty:     { side: "✨", he: "כרטיס VIP",      en: "VIP Card",  ar: "بطاقة VIP",   ru: "VIP Карта",  ph: "VIP #219",   flow: "exit" },
    general:    { side: "◆",  he: "מספר אסמכתא",    en: "Ref #",     ar: "رقم المرجع",  ru: "Номер #",    ph: "#4821",      flow: "exit" }
  };

  async function sha256Hex(str) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(str)));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
  }

  async function hashPin(scope, rawPin) {
    return sha256Hex(`LYNX_V8_SALT::${scope}::${String(rawPin).trim()}`);
  }

  async function sig8(payload) {
    return (await sha256Hex("LYNX_V8_SIG::" + payload)).slice(0, 8).toUpperCase();
  }

  function escHtml(s) {
    return String(s || "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
  }
  function cleanPhone(p) { return String(p || "").replace(/\D/g, "").slice(0, 12); }
  function formatILPhone(p) {
    const d = cleanPhone(p);
    return d.length <= 3 ? d : d.slice(0, 3) + "-" + d.slice(3, 10);
  }
  function toIntlIL(p) {
    const d = cleanPhone(p);
    if (!d) return "";
    if (d.startsWith("972")) return d;
    if (d.startsWith("0") && d.length >= 9) return "972" + d.slice(1);
    return d;
  }
  function isIOS() { return /iPad|iPhone|iPod/.test(navigator.userAgent); }
  function sanitizeUrl(u) {
    const s = String(u || "").trim();
    if (!s) return "";
    try {
      const p = new URL(s.startsWith("http") ? s : "https://" + s);
      return (p.protocol === "https:" || p.protocol === "http:") ? p.toString() : "";
    } catch { return ""; }
  }
  function b64uEncode(obj) {
    const bytes = new TextEncoder().encode(JSON.stringify(obj));
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function b64uDecode(str) {
    try {
      let s = String(str || "").replace(/-/g, "+").replace(/_/g, "/");
      while (s.length % 4) s += "=";
      const bin = atob(s);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return JSON.parse(new TextDecoder().decode(bytes));
    } catch { return null; }
  }
  function resolveWorkerRoot(customBase) {
    const c = sanitizeUrl(customBase);
    if (c) return c.replace(/\/(master|index)\.html$/i, "").replace(/\/+$/, "");
    if (location.protocol === "http:" || location.protocol === "https:") {
      return location.origin;
    }
    return DEFAULT_WORKER;
  }
  function formatVisualSms(intro, url) {
    const lines = String(intro || "").trim().split("\n").slice(0, 2).join("\n");
    return RLM + lines + "\n\n" + LRM + String(url || "").trim();
  }
  function detectCategory(name, addr) {
    const hay = `${name || ""} ${addr || ""}`.toLowerCase();
    const rules = [
      ["auto", ["פרונט","מוסך","צמיג","רכב","שטיפה","טסט","auto","garage","car"]],
      ["zimmer", ["צימר","מלון","סוויטה","וילה","hotel","zimmer","suite"]],
      ["attraction", ["טרקטורון","ספא","אטרקציה","קיאק","spa","tour"]],
      ["lab", ["מעבדה","סלולר","מחשב","תיקון","מכבסה","repair","lab"]],
      ["food", ["פלאפל","מסעדה","קפה","פיצה","food","cafe","grill"]],
      ["beauty", ["מספרה","שיער","קוסמטי","יופי","salon","barber"]]
    ];
    for (const [cat, kws] of rules) if (kws.some(k => hay.includes(k))) return cat;
    return "general";
  }
  function showToast(msg) {
    const el = document.getElementById("lynxToast");
    if (!el) return;
    el.textContent = msg;
    el.style.display = "block";
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.style.display = "none"; }, 2600);
  }
  function downloadFile(name, content, mime) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([content], { type: mime }));
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
  }

  function createDB(dbName) {
    const DB_VER = 1;
    let dbPromise = null;
    function open() {
      if (dbPromise) return dbPromise;
      dbPromise = new Promise((resolve, reject) => {
        const req = indexedDB.open(dbName, DB_VER);
        req.onupgradeneeded = () => {
          const d = req.result;
          if (!d.objectStoreNames.contains("state")) d.createObjectStore("state");
          if (!d.objectStoreNames.contains("fifo_queue")) d.createObjectStore("fifo_queue", { keyPath: "seq", autoIncrement: true });
          if (!d.objectStoreNames.contains("tech_logs")) d.createObjectStore("tech_logs", { keyPath: "id", autoIncrement: true });
          if (!d.objectStoreNames.contains("scan_history")) d.createObjectStore("scan_history", { keyPath: "id", autoIncrement: true });
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
      return dbPromise;
    }
    async function tx(store, mode, fn) {
      const d = await open();
      return new Promise((resolve, reject) => {
        const t = d.transaction(store, mode);
        const res = fn(t.objectStore(store));
        t.oncomplete = () => resolve(res && "result" in res ? res.result : res);
        t.onerror = () => reject(t.error);
      });
    }
    return {
      getState: (k) => tx("state", "readonly", s => s.get(k)),
      setState: (k, v) => tx("state", "readwrite", s => s.put(v, k)),
      enqueueFifo: (job) => tx("fifo_queue", "readwrite", s => s.add({ ...job, createdAt: Date.now() })),
      listFifo: () => tx("fifo_queue", "readonly", s => s.getAll()),
      deleteFifo: (seq) => tx("fifo_queue", "readwrite", s => s.delete(seq)),
      addLog: (entry) => tx("tech_logs", "readwrite", s => s.add({ ts: new Date().toISOString(), ...entry })),
      listLogs: () => tx("tech_logs", "readonly", s => s.getAll()),
      clearLogs: () => tx("tech_logs", "readwrite", s => s.clear()),
      addScan: (rec) => tx("scan_history", "readwrite", s => s.add(rec)),
      listScans: () => tx("scan_history", "readonly", s => s.getAll()),
      clearScans: () => tx("scan_history", "readwrite", s => s.clear())
    };
  }

  function wireLangDropdown(btnId, menuId, onPick) {
    const btn = document.getElementById(btnId);
    const menu = document.getElementById(menuId);
    if (!btn || !menu) return;
    btn.addEventListener("click", (e) => { e.stopPropagation(); menu.classList.toggle("open"); });
    menu.addEventListener("click", (e) => {
      const opt = e.target.closest("[data-lang]");
      if (!opt) return;
      menu.classList.remove("open");
      onPick(opt.dataset.lang);
    });
    document.addEventListener("click", () => menu.classList.remove("open"));
  }

  function wirePinKeypad(keypadId, inputId, onEnter) {
    const pad = document.getElementById(keypadId);
    const inp = document.getElementById(inputId);
    if (!pad || !inp) return;
    pad.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-key]");
      if (!btn) return;
      const k = btn.dataset.key;
      if (k === "back") inp.value = inp.value.slice(0, -1);
      else if (k === "clear") inp.value = "";
      else if (k === "ok") onEnter();
      else if (inp.value.length < 8) inp.value += k;
    });
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") onEnter(); });
  }

  function applyDirection(lang) {
    const rtl = (lang === "he" || lang === "ar");
    document.documentElement.lang = lang;
    document.documentElement.dir = rtl ? "rtl" : "ltr";
  }

  async function initPwaOta(logFn, onBanner) {
    if ("serviceWorker" in navigator) {
      try {
        const reg = await navigator.serviceWorker.register("./sw.js");
        reg.addEventListener("updatefound", () => logFn("INFO", "SW_UPDATE", "New Service Worker update detected"));
      } catch (err) {
        await logFn("WARN", "SW_REG_FAIL", err.message);
      }
    }
    try {
      const res = await fetch("./updates.json?t=" + Date.now(), { cache: "no-store" });
      if (res.ok) {
        const ota = await res.json();
        if (ota.banner_active && onBanner) onBanner(ota);
        return ota;
      }
    } catch (_) {}
    return null;
  }

  global.LynxCore = {
    SCHEMA_VER, DEFAULT_WORKER, LRM, RLM, CAT_KEYS, CAT_META,
    sha256Hex, hashPin, sig8, escHtml, cleanPhone, formatILPhone, toIntlIL, isIOS,
    sanitizeUrl, b64uEncode, b64uDecode, resolveWorkerRoot, formatVisualSms,
    detectCategory, showToast, downloadFile, createDB, wireLangDropdown,
    wirePinKeypad, applyDirection, initPwaOta
  };
})(window);
