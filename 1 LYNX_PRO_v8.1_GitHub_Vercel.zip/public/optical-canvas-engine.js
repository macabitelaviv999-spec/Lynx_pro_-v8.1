/* ==========================================================================
 * LYNX PRO v8.0 — Isolated HTML5 Canvas Optical Engine (Rule 10)
 * - Decouples live <video> into HTML5 <canvas> frame pipeline (zero DOM jitter)
 * - Isolated Focus Window (ROI): freely draggable, resizable, zoom-decoupled (< 1s)
 * - Targeted ROI-only scanning:
 *     1) Complex Barcodes & QR (all 13 BarcodeDetector formats + contrast pass)
 *     2) Offline Local Digits OCR (Otsu thresholding + connected projection + 7x10 template matcher)
 * - Full Manual Override feeding the exact same validation pipeline
 * ========================================================================== */
(function (global) {
  "use strict";

  const ALL_BARCODE_FORMATS = [
    "qr_code", "ean_13", "ean_8", "code_128", "code_39", "code_93",
    "codabar", "itf", "upc_a", "upc_e", "pdf417", "aztec", "data_matrix"
  ];

  // Compact 7x10 printed/plate digit bitmaps (0-9) for 100% offline local ROI OCR
  const DIGIT_TEMPLATES = {
    "0": [
      "0111110","1100011","1100011","1100111","1101011",
      "1110011","1100011","1100011","1100011","0111110"
    ],
    "1": [
      "0001100","0011100","0111100","0001100","0001100",
      "0001100","0001100","0001100","0001100","0111111"
    ],
    "2": [
      "0111110","1100011","0000011","0000110","0001100",
      "0011000","0110000","1100000","1100011","1111111"
    ],
    "3": [
      "0111110","1100011","0000011","0001110","0000011",
      "0000011","0000011","1100011","1100011","0111110"
    ],
    "4": [
      "0000110","0001110","0011110","0110110","1100110",
      "1111111","0000110","0000110","0000110","0000110"
    ],
    "5": [
      "1111111","1100000","1100000","1111110","0000011",
      "0000011","0000011","0000011","1100011","0111110"
    ],
    "6": [
      "0011110","0110000","1100000","1111110","1100011",
      "1100011","1100011","1100011","1100011","0111110"
    ],
    "7": [
      "1111111","1100011","0000110","0001100","0001100",
      "0011000","0011000","0011000","0011000","0011000"
    ],
    "8": [
      "0111110","1100011","1100011","1100011","0111110",
      "1100011","1100011","1100011","1100011","0111110"
    ],
    "9": [
      "0111110","1100011","1100011","1100011","0111111",
      "0000011","0000011","0000110","0111100","0111000"
    ]
  };
  const FLAT_TEMPLATES = Object.fromEntries(
    Object.entries(DIGIT_TEMPLATES).map(([d, rows]) => [d, rows.join("").split("").map(Number)])
  );

  // Offline Local ROI Digits OCR Engine
  const LocalDigitsOCR = {
    otsuThreshold(gray) {
      const hist = new Uint32Array(256);
      for (let i = 0; i < gray.length; i++) hist[gray[i]]++;
      const total = gray.length;
      let sum = 0;
      for (let t = 0; t < 256; t++) sum += t * hist[t];
      let sumB = 0, wB = 0, maxVar = 0, thresh = 128;
      for (let t = 0; t < 256; t++) {
        wB += hist[t];
        if (!wB) continue;
        const wF = total - wB;
        if (!wF) break;
        sumB += t * hist[t];
        const mB = sumB / wB;
        const mF = (sum - sumB) / wF;
        const v = wB * wF * (mB - mF) * (mB - mF);
        if (v > maxVar) { maxVar = v; thresh = t; }
      }
      return thresh;
    },

    recognize(canvas) {
      const w = canvas.width, h = canvas.height;
      if (w < 32 || h < 18) return null;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      const img = ctx.getImageData(0, 0, w, h).data;
      const gray = new Uint8Array(w * h);
      let minL = 255, maxL = 0;
      for (let i = 0, p = 0; i < img.length; i += 4, p++) {
        const y = (img[i] * 77 + img[i + 1] * 150 + img[i + 2] * 29) >> 8;
        gray[p] = y;
        if (y < minL) minL = y;
        if (y > maxL) maxL = y;
      }
      const range = maxL - minL;
      if (range < 36) return null; // Too low contrast / blurry frame

      // Contrast stretch
      for (let p = 0; p < gray.length; p++) {
        gray[p] = Math.round(((gray[p] - minL) * 255) / range);
      }
      const thresh = this.otsuThreshold(gray);

      // Determine polarity (dark text on light background vs light text on dark background)
      let darkCount = 0;
      for (let p = 0; p < gray.length; p++) if (gray[p] < thresh) darkCount++;
      const darkInk = darkCount < gray.length * 0.55;
      const bin = new Uint8Array(w * h);
      for (let p = 0; p < gray.length; p++) {
        bin[p] = darkInk ? (gray[p] < thresh ? 1 : 0) : (gray[p] > thresh ? 1 : 0);
      }

      // Horizontal band cropping (trim top/bottom empty rows)
      let y0 = 0, y1 = h - 1;
      for (let y = 0; y < h; y++) {
        let s = 0; for (let x = 0; x < w; x++) s += bin[y * w + x];
        if (s > w * 0.03) { y0 = y; break; }
      }
      for (let y = h - 1; y >= y0; y--) {
        let s = 0; for (let x = 0; x < w; x++) s += bin[y * w + x];
        if (s > w * 0.03) { y1 = y; break; }
      }
      const bandH = y1 - y0 + 1;
      if (bandH < 12) return null;

      // Vertical projection segmentation for digits
      const colCounts = new Uint16Array(w);
      for (let x = 0; x < w; x++) {
        let c = 0;
        for (let y = y0; y <= y1; y++) c += bin[y * w + x];
        colCounts[x] = c;
      }

      const boxes = [];
      let inSeg = false, sx = 0;
      for (let x = 0; x < w; x++) {
        const active = colCounts[x] >= Math.max(2, bandH * 0.08);
        if (active && !inSeg) { inSeg = true; sx = x; }
        else if (!active && inSeg) {
          inSeg = false;
          const segW = x - sx;
          if (segW >= 3 && segW <= bandH * 1.15) boxes.push([sx, x - 1]);
        }
      }
      if (inSeg) {
        const segW = w - sx;
        if (segW >= 3 && segW <= bandH * 1.15) boxes.push([sx, w - 1]);
      }
      if (boxes.length < 4 || boxes.length > 14) return null;

      let digits = "";
      let totalScore = 0;
      let validDigits = 0;

      for (const [bx0, bx1] of boxes) {
        // Tight vertical crop per character
        let cy0 = y0, cy1 = y1;
        while (cy0 < cy1) {
          let s = 0; for (let x = bx0; x <= bx1; x++) s += bin[cy0 * w + x];
          if (s > 0) break; cy0++;
        }
        while (cy1 > cy0) {
          let s = 0; for (let x = bx0; x <= bx1; x++) s += bin[cy1 * w + x];
          if (s > 0) break; cy1--;
        }
        const cw = bx1 - bx0 + 1, ch = cy1 - cy0 + 1;
        if (ch < bandH * 0.45) continue; // Ignore dashes / dots / noise

        // Sample onto 7x10 normalized grid
        const vec = new Uint8Array(70);
        let ones = 0;
        for (let ty = 0; ty < 10; ty++) {
          const sy = Math.min(cy1, cy0 + Math.floor((ty + 0.5) * ch / 10));
          for (let tx = 0; tx < 7; tx++) {
            const sx2 = Math.min(bx1, bx0 + Math.floor((tx + 0.5) * cw / 7));
            const v = bin[sy * w + sx2];
            vec[ty * 7 + tx] = v;
            ones += v;
          }
        }
        if (ones < 8 || ones > 64) continue;

        // Narrow aspect ratio boost for "1"
        const aspect = cw / ch;
        let bestDigit = "", bestSim = -1;
        for (const [d, tpl] of Object.entries(FLAT_TEMPLATES)) {
          let match = 0;
          for (let k = 0; k < 70; k++) {
            if (vec[k] === tpl[k]) match += (tpl[k] ? 1.35 : 0.85);
          }
          let sim = match / 78;
          if (d === "1" && aspect < 0.38) sim += 0.14;
          if (sim > bestSim) { bestSim = sim; bestDigit = d; }
        }
        if (bestSim >= 0.68) {
          digits += bestDigit;
          totalScore += bestSim;
          validDigits++;
        }
      }

      if (validDigits < 4) return null;
      const avgConf = totalScore / validDigits;
      if (avgConf < 0.72) return null;

      // Format 7 or 8 digit Israeli plates automatically
      let formatted = digits;
      if (digits.length === 7) formatted = `${digits.slice(0,2)}-${digits.slice(2,5)}-${digits.slice(5)}`;
      else if (digits.length === 8) formatted = `${digits.slice(0,3)}-${digits.slice(3,5)}-${digits.slice(5)}`;
      return { text: formatted, raw: digits, confidence: Number(avgConf.toFixed(2)) };
    }
  };

  class LynxOpticalCanvasEngine {
    constructor(opts) {
      this.stageEl = opts.stageEl;
      this.videoEl = opts.videoEl;
      this.canvasEl = opts.canvasEl;
      this.ctx = this.canvasEl.getContext("2d", { alpha: false });
      this.roiEl = opts.roiEl;
      this.roiHandleEl = opts.roiHandleEl;
      this.roiLabelEl = opts.roiLabelEl;
      this.statusEl = opts.statusEl;
      this.zoomSlider = opts.zoomSlider;
      this.manualInputEl = opts.manualInputEl;
      this.onResult = opts.onResult || (() => {});
      this.onLog = opts.onLog || (() => {});

      this.stream = null;
      this.track = null;
      this.detector = null;
      this.supportedFormats = [];
      this.running = false;
      this.decoupled = false;
      this.stabilizeTimer = null;
      this.rafId = null;

      this.scanMode = "auto"; // "auto" | "barcode" | "ocr"
      this.zoomLevel = 1.0;
      this.STABILIZE_MS = 500;       // < 1s focus recovery
      this.SCAN_INTERVAL_MS = 120;
      this.MOTION_THRESHOLD = 17.0;
      this.lastScanTs = 0;
      this.lastCode = "";
      this.lastCodeTs = 0;
      this.ocrConsensus = { text: "", count: 0 };

      // Normalized ROI coordinates (0..1 relative to canvas viewport)
      this.roi = { x: 0.14, y: 0.24, w: 0.72, h: 0.44 };

      // Offscreen canvases for strict ROI-only decoding & motion detection
      this.roiCanvas = document.createElement("canvas");
      this.roiCtx = this.roiCanvas.getContext("2d", { willReadFrequently: true });
      this.motionCanvas = document.createElement("canvas");
      this.motionCanvas.width = 48;
      this.motionCanvas.height = 36;
      this.motionCtx = this.motionCanvas.getContext("2d", { willReadFrequently: true });
      this.prevLuma = null;
      this.frameCounter = 0;

      // Viewport cover transform cache (maps canvas pixels <-> raw video pixels)
      this.coverMap = { sx: 0, sy: 0, sw: 1, sh: 1, cw: 1, ch: 1 };

      this.bindRoiInteractions();
      this.syncRoiDom();
    }

    setScanMode(mode) {
      this.scanMode = ["auto", "barcode", "ocr"].includes(mode) ? mode : "auto";
      this.ocrConsensus = { text: "", count: 0 };
      if (this.roiLabelEl) {
        const tag = this.scanMode === "ocr" ? "ROI OCR (ספרות)" : this.scanMode === "barcode" ? "ROI ברקוד/QR" : "ROI חכם (ברקוד + OCR)";
        this.roiLabelEl.textContent = tag;
      }
      this.onLog("INFO", "SCAN_MODE", `Switched local ROI scan mode to ${this.scanMode}`);
    }

    adjustRoiSize(delta) {
      const cx = this.roi.x + this.roi.w / 2;
      const cy = this.roi.y + this.roi.h / 2;
      const nw = Math.max(0.24, Math.min(0.94, this.roi.w + delta));
      const nh = Math.max(0.16, Math.min(0.86, this.roi.h + delta * 0.75));
      this.roi.w = nw;
      this.roi.h = nh;
      this.roi.x = Math.max(0.03, Math.min(0.97 - nw, cx - nw / 2));
      this.roi.y = Math.max(0.06, Math.min(0.94 - nh, cy - nh / 2));
      this.syncRoiDom();
      this.triggerDecouple("שינוי גודל חלונית פוקוס");
    }

    resetRoi() {
      this.roi = { x: 0.14, y: 0.24, w: 0.72, h: 0.44 };
      this.syncRoiDom();
      this.triggerDecouple("איפוס חלונית פוקוס");
    }

    syncRoiDom() {
      if (!this.roiEl) return;
      this.roiEl.style.left = `${(this.roi.x * 100).toFixed(2)}%`;
      this.roiEl.style.top = `${(this.roi.y * 100).toFixed(2)}%`;
      this.roiEl.style.width = `${(this.roi.w * 100).toFixed(2)}%`;
      this.roiEl.style.height = `${(this.roi.h * 100).toFixed(2)}%`;
    }

    bindRoiInteractions() {
      if (!this.roiEl || !this.stageEl) return;
      let dragMode = null; // "move" | "resize"
      let startX = 0, startY = 0, startRoi = null;

      const onDown = (e, mode) => {
        e.preventDefault();
        e.stopPropagation();
        dragMode = mode;
        startX = e.clientX;
        startY = e.clientY;
        startRoi = { ...this.roi };
        this.roiEl.classList.add(mode === "move" ? "roi-dragging" : "roi-resizing");
        this.triggerDecouple(mode === "move" ? "הזזת חלונית פוקוס" : "הגדלת/הקטנת פוקוס");
        try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
      };

      const onMove = (e) => {
        if (!dragMode || !startRoi) return;
        const rect = this.stageEl.getBoundingClientRect();
        if (!rect.width || !rect.height) return;
        const dx = (e.clientX - startX) / rect.width;
        const dy = (e.clientY - startY) / rect.height;
        if (dragMode === "move") {
          this.roi.x = Math.max(0.02, Math.min(0.98 - startRoi.w, startRoi.x + dx));
          this.roi.y = Math.max(0.05, Math.min(0.95 - startRoi.h, startRoi.y + dy));
        } else {
          const nw = Math.max(0.24, Math.min(0.96 - startRoi.x, startRoi.w + dx));
          const nh = Math.max(0.16, Math.min(0.94 - startRoi.y, startRoi.h + dy));
          this.roi.w = nw;
          this.roi.h = nh;
        }
        this.syncRoiDom();
        this.triggerDecouple("מיקוד אזורי");
      };

      const onUp = () => {
        if (!dragMode) return;
        dragMode = null;
        this.roiEl.classList.remove("roi-dragging", "roi-resizing");
        this.applyHardwarePointOfInterest();
      };

      this.roiEl.addEventListener("pointerdown", (e) => {
        if (e.target === this.roiHandleEl) return;
        onDown(e, "move");
      });
      this.roiEl.addEventListener("pointermove", onMove);
      this.roiEl.addEventListener("pointerup", onUp);
      this.roiEl.addEventListener("pointercancel", onUp);

      if (this.roiHandleEl) {
        this.roiHandleEl.addEventListener("pointerdown", (e) => onDown(e, "resize"));
        this.roiHandleEl.addEventListener("pointermove", onMove);
        this.roiHandleEl.addEventListener("pointerup", onUp);
        this.roiHandleEl.addEventListener("pointercancel", onUp);
      }
    }

    async applyHardwarePointOfInterest() {
      if (!this.track || typeof this.track.getCapabilities !== "function") return;
      const caps = this.track.getCapabilities();
      const adv = {};
      if (caps.focusMode && caps.focusMode.includes("continuous")) adv.focusMode = "continuous";
      if (caps.pointsOfInterest) {
        adv.pointsOfInterest = [{ x: this.roi.x + this.roi.w / 2, y: this.roi.y + this.roi.h / 2 }];
      }
      if (Object.keys(adv).length) {
        try { await this.track.applyConstraints({ advanced: [adv] }); } catch (_) {}
      }
    }

    setContainerExpanded(expanded) {
      if (!this.stageEl) return;
      const cur = this.stageEl.classList.contains("cam-expanded");
      if (expanded && !cur) {
        this.stageEl.classList.add("cam-expanded");
        this.stageEl.setAttribute("data-cam-state", "expanded");
        this.onLog("INFO", "CAM_EXPAND", "HTML5 Canvas camera expanded stably (svh-locked)");
      } else if (!expanded && cur) {
        this.stageEl.classList.remove("cam-expanded");
        this.stageEl.setAttribute("data-cam-state", "compact");
        this.onLog("INFO", "CAM_COLLAPSE", "HTML5 Canvas camera restored to compact proportion");
      }
    }

    setStatus(text, tone = "ok") {
      if (!this.statusEl) return;
      this.statusEl.textContent = text;
      this.statusEl.className = "status-bar " + (tone === "warn" ? "status-warn" : "status-ok");
    }

    async initDetector() {
      if ("BarcodeDetector" in global) {
        try {
          const native = await global.BarcodeDetector.getSupportedFormats();
          this.supportedFormats = ALL_BARCODE_FORMATS.filter(f => native.includes(f));
          if (!this.supportedFormats.length) this.supportedFormats = native;
          this.detector = new global.BarcodeDetector({ formats: this.supportedFormats });
          this.onLog("INFO", "OPTICAL_INIT", `BarcodeDetector (${this.supportedFormats.length} formats) + Local Digits OCR ready`);
          return true;
        } catch (err) {
          this.onLog("WARN", "DETECTOR_ERR", err.message);
        }
      }
      this.detector = null;
      this.onLog("INFO", "OCR_ONLY_FALLBACK", "BarcodeDetector absent; Local ROI Digits OCR + Manual Override active");
      return false;
    }

    async start() {
      if (this.running) return;
      await this.initDetector();
      this.setContainerExpanded(true);
      this.setStatus("מפעיל מצלמה לתוך Canvas HTML5 ומייצב ROI...", "warn");
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            facingMode: { ideal: "environment" },
            width: { ideal: 1280 },
            height: { ideal: 720 },
            focusMode: { ideal: "continuous" }
          }
        });
        this.videoEl.srcObject = this.stream;
        await this.videoEl.play();
        this.track = this.stream.getVideoTracks()[0] || null;
        this.configureHardwareCapabilities();
        this.running = true;
        this.decoupled = false;
        this.prevLuma = null;
        this.ocrConsensus = { text: "", count: 0 };
        this.setStatus(`Canvas ROI פעיל • ${this.supportedFormats.length} פורמטי ברקוד + OCR ספרות מקומי`, "ok");
        this.loop(performance.now());
      } catch (err) {
        this.setContainerExpanded(false);
        this.setStatus("אין גישה למצלמה — השתמש בשדה ההזנה הידנית למטה", "warn");
        this.onLog("ERROR", "CAMERA_FAIL", err.message);
      }
    }

    stop() {
      this.running = false;
      this.decoupled = false;
      if (this.rafId) cancelAnimationFrame(this.rafId);
      if (this.stabilizeTimer) clearTimeout(this.stabilizeTimer);
      if (this.stream) {
        this.stream.getTracks().forEach(t => t.stop());
        this.stream = null;
        this.track = null;
      }
      if (this.videoEl) this.videoEl.srcObject = null;
      this.zoomLevel = 1.0;
      if (this.zoomSlider) this.zoomSlider.value = this.zoomSlider.min || 1;
      if (this.ctx) this.ctx.clearRect(0, 0, this.canvasEl.width, this.canvasEl.height);
      this.setContainerExpanded(false);
      this.setStatus("הסורק כבוי — הקונטיינר הוחזר לפרופורציה המקורית", "warn");
    }

    configureHardwareCapabilities() {
      if (!this.track || typeof this.track.getCapabilities !== "function") return;
      const caps = this.track.getCapabilities();
      if (this.zoomSlider) {
        this.zoomSlider.min = caps.zoom ? (caps.zoom.min || 1) : 1;
        this.zoomSlider.max = caps.zoom ? Math.min(caps.zoom.max || 4, 6) : 3.5;
        this.zoomSlider.step = caps.zoom ? (caps.zoom.step || 0.1) : 0.1;
        this.zoomSlider.value = this.zoomSlider.min;
      }
    }

    triggerDecouple(reason) {
      if (!this.running) return;
      if (!this.decoupled) {
        this.decoupled = true;
        this.ocrConsensus = { text: "", count: 0 };
        this.setStatus(`מייצב פוקוס (${reason}) — סריקת ROI מושהית רגעית...`, "warn");
      }
      clearTimeout(this.stabilizeTimer);
      this.stabilizeTimer = setTimeout(() => {
        this.decoupled = false;
        this.prevLuma = null;
        if (this.running) {
          this.setStatus(`פוקוס יציב • סריקת ROI ממוקדת פעילה (${this.scanMode.toUpperCase()})`, "ok");
        }
      }, this.STABILIZE_MS);
    }

    async setZoom(val) {
      const z = Math.max(1, Number(val) || 1);
      this.triggerDecouple(`זום x${z.toFixed(1)}`);
      if (this.track && typeof this.track.getCapabilities === "function" && this.track.getCapabilities().zoom) {
        try {
          await this.track.applyConstraints({ advanced: [{ zoom: z }] });
          this.zoomLevel = 1.0; // Handled optically by lens
          return;
        } catch (_) {}
      }
      this.zoomLevel = z; // Smooth canvas crop zoom
    }

    // Renders live video frame into HTML5 <canvas> with darkened mask outside isolated ROI
    renderCanvasFrame() {
      const rect = this.stageEl.getBoundingClientRect();
      const cw = Math.max(1, Math.round(rect.width));
      const ch = Math.max(1, Math.round(rect.height));
      if (this.canvasEl.width !== cw || this.canvasEl.height !== ch) {
        this.canvasEl.width = cw;
        this.canvasEl.height = ch;
      }
      const vw = this.videoEl.videoWidth, vh = this.videoEl.videoHeight;
      if (!vw || !vh) return false;

      // Compute object-fit: cover + digital canvas zoom
      const vAspect = vw / vh, cAspect = cw / ch;
      let sw = vw, sh = vh;
      if (vAspect > cAspect) { sw = vh * cAspect; } else { sh = vw / cAspect; }
      sw /= this.zoomLevel;
      sh /= this.zoomLevel;
      const sx = (vw - sw) / 2;
      const sy = (vh - sh) / 2;
      this.coverMap = { sx, sy, sw, sh, cw, ch };

      this.ctx.drawImage(this.videoEl, sx, sy, sw, sh, 0, 0, cw, ch);

      // Draw translucent vignette outside the isolated ROI focus window
      const rx = Math.round(this.roi.x * cw);
      const ry = Math.round(this.roi.y * ch);
      const rw = Math.round(this.roi.w * cw);
      const rh = Math.round(this.roi.h * ch);

      this.ctx.save();
      this.ctx.fillStyle = "rgba(4, 8, 18, 0.56)";
      this.ctx.beginPath();
      this.ctx.rect(0, 0, cw, ch);
      this.ctx.rect(rx, ry, rw, rh);
      this.ctx.fill("evenodd");
      this.ctx.restore();
      return true;
    }

    // Crops ONLY the isolated focus window from the full-resolution raw video stream
    extractLocalRoiCanvas() {
      const { sx, sy, sw, sh } = this.coverMap;
      const cropX = Math.max(0, Math.round(sx + this.roi.x * sw));
      const cropY = Math.max(0, Math.round(sy + this.roi.y * sh));
      const cropW = Math.max(32, Math.round(this.roi.w * sw));
      const cropH = Math.max(24, Math.round(this.roi.h * sh));

      const targetW = Math.min(640, cropW);
      const targetH = Math.max(24, Math.round(cropH * (targetW / cropW)));
      this.roiCanvas.width = targetW;
      this.roiCanvas.height = targetH;
      this.roiCtx.filter = "none";
      this.roiCtx.drawImage(this.videoEl, cropX, cropY, cropW, cropH, 0, 0, targetW, targetH);
      return this.roiCanvas;
    }

    detectRoiMotion() {
      const w = this.motionCanvas.width, h = this.motionCanvas.height;
      this.motionCtx.drawImage(this.roiCanvas, 0, 0, w, h);
      const data = this.motionCtx.getImageData(0, 0, w, h).data;
      const luma = new Uint8Array(w * h);
      let diff = 0;
      for (let i = 0, p = 0; i < data.length; i += 4, p++) {
        const y = (data[i] * 77 + data[i + 1] * 150 + data[i + 2] * 29) >> 8;
        luma[p] = y;
        if (this.prevLuma) diff += Math.abs(y - this.prevLuma[p]);
      }
      const had = !!this.prevLuma;
      this.prevLuma = luma;
      return had && (diff / luma.length) > this.MOTION_THRESHOLD;
    }

    flashRoiLock() {
      if (!this.roiEl) return;
      this.roiEl.classList.add("roi-locked");
      clearTimeout(this.roiEl._lockT);
      this.roiEl._lockT = setTimeout(() => this.roiEl.classList.remove("roi-locked"), 600);
    }

    emitHit(value, format, source) {
      const now = Date.now();
      if (value === this.lastCode && now - this.lastCodeTs < 2000) return;
      this.lastCode = value;
      this.lastCodeTs = now;
      this.flashRoiLock();
      try { if (navigator.vibrate) navigator.vibrate([24, 28, 24]); } catch (_) {}
      this.onResult({ value, format, source, ts: now });
    }

    async scanLocalRoi() {
      this.frameCounter++;
      const roi = this.extractLocalRoiCanvas();
      if (this.detectRoiMotion()) {
        this.triggerDecouple("תנועה באזור הפוקוס");
        return;
      }

      // 1) Targeted Complex Barcode & QR Pass (strictly inside ROI)
      if (this.detector && (this.scanMode === "auto" || this.scanMode === "barcode")) {
        try {
          let hits = await this.detector.detect(roi);
          if ((!hits || !hits.length) && this.frameCounter % 2 === 0) {
            // High-contrast ROI enhancement pass for difficult/reflective barcodes
            this.roiCtx.filter = "contrast(1.45) grayscale(1)";
            this.roiCtx.drawImage(roi, 0, 0);
            hits = await this.detector.detect(roi);
          }
          if (hits && hits.length) {
            const best = hits[0];
            const val = String(best.rawValue || "").trim();
            if (val) {
              this.emitHit(val, best.format || "barcode", "canvas-roi");
              return;
            }
          }
        } catch (err) {
          this.onLog("WARN", "ROI_BARCODE_ERR", err.message);
        }
      }

      // 2) Targeted Offline Local Digits OCR Pass (strictly inside ROI)
      if (this.scanMode === "ocr" || (this.scanMode === "auto" && this.frameCounter % 3 === 0)) {
        const ocr = LocalDigitsOCR.recognize(roi);
        if (ocr && ocr.text) {
          if (this.ocrConsensus.text === ocr.text) {
            this.ocrConsensus.count++;
          } else {
            this.ocrConsensus = { text: ocr.text, count: 1 };
          }
          // Require 2 consecutive consistent readings for rock-solid accuracy
          if (this.ocrConsensus.count >= 2) {
            this.ocrConsensus = { text: "", count: 0 };
            this.emitHit(ocr.text, `ocr_digits(${Math.round(ocr.confidence * 100)}%)`, "canvas-roi-ocr");
          }
        }
      }
    }

    submitManual(rawValue) {
      const val = String(rawValue || "").trim();
      if (!val) return false;
      this.onResult({ value: val, format: "manual_override", source: "manual", ts: Date.now() });
      if (this.manualInputEl) this.manualInputEl.value = "";
      return true;
    }

    async loop(now) {
      if (!this.running) return;
      const painted = this.renderCanvasFrame();
      if (painted && !this.decoupled && (now - this.lastScanTs >= this.SCAN_INTERVAL_MS)) {
        this.lastScanTs = now;
        await this.scanLocalRoi();
      }
      this.rafId = requestAnimationFrame(t => this.loop(t));
    }
  }

  global.LynxOpticalCanvasEngine = LynxOpticalCanvasEngine;
  global.LynxLocalDigitsOCR = LocalDigitsOCR;
})(window);
