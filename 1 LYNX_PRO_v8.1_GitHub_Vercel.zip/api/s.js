import { escHtml, getOrigin, kvGetJson } from "./_kv.js";

export default async function handler(req, res) {
  const code = String((req.query && req.query.code) || "").replace(/[^a-zA-Z0-9_-]/g, "");
  if (!code) return res.status(404).send("Not Found");

  try {
    const rec = await kvGetJson(`lynx:s:${code}`);
    if (!rec || !rec.url) return res.status(404).send("Link expired or not found");

    const ua = String(req.headers["user-agent"] || "");
    const isBot = /WhatsApp|facebookexternalhit|TelegramBot|Twitterbot|Slackbot|Googlebot|Applebot|LinkedInBot/i.test(ua);
    if (!isBot) {
      res.setHeader("Location", rec.url);
      return res.status(302).end();
    }

    const origin = getOrigin(req);
    const title = escHtml(rec.title || "LYNX PRO");
    const safeUrl = escHtml(rec.url);
    const html = `<!DOCTYPE html><html lang="he" dir="rtl"><head>
<meta charset="UTF-8" />
<title>${title} — LYNX PRO</title>
<meta property="og:type" content="website" />
<meta property="og:title" content="${title} — קבלה דיגיטלית והטבת VIP" />
<meta property="og:description" content="קבלה דיגיטלית מאומתת וקוד QR חכם לפתיחה מיידית בכל טלפון." />
<meta property="og:image" content="${origin}/preview.jpg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta http-equiv="refresh" content="0;url=${safeUrl}" />
</head><body></body></html>`;

    res.setHeader("Content-Type", "text/html; charset=UTF-8");
    return res.status(200).send(html);
  } catch (err) {
    return res.status(err.statusCode || 500).send(err.message);
  }
}
