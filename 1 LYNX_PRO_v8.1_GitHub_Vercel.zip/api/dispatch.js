import { setCors } from "./_kv.js";

export default async function handler(req, res) {
  setCors(req, res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Method Not Allowed" });

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    if (!body || !body.event) {
      return res.status(400).json({ ok: false, error: "Missing event" });
    }

    const upstreamUrl = process.env.UPSTREAM_WEBHOOK_URL;
    if (upstreamUrl) {
      const headers = { "Content-Type": "application/json" };
      if (process.env.UPSTREAM_BEARER_TOKEN) {
        headers["Authorization"] = `Bearer ${process.env.UPSTREAM_BEARER_TOKEN}`;
      }
      const up = await fetch(upstreamUrl, {
        method: "POST",
        headers,
        body: JSON.stringify(body)
      });
      if (!up.ok) {
        return res.status(502).json({ ok: false, upstreamStatus: up.status });
      }
    }

    return res.status(200).json({ ok: true, receivedAt: Date.now() });
  } catch (err) {
    return res.status(500).json({ ok: false, error: err.message });
  }
}
