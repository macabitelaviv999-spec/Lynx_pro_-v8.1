/* Shared zero-dependency Vercel KV / Upstash Redis REST client & HTTP helpers */
export function setCors(req, res) {
  const origin = req.headers.origin || "*";
  res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Vary", "Origin");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
}

export function getOrigin(req) {
  const proto = (req.headers["x-forwarded-proto"] || "https").split(",")[0].trim();
  const host = (req.headers["x-forwarded-host"] || req.headers.host || "localhost:3000").split(",")[0].trim();
  return `${proto}://${host}`;
}

export function escHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

export function getKvConfig() {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL || "";
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN || "";
  return { url: url.replace(/\/+$/, ""), token, configured: Boolean(url && token) };
}

async function kvCommand(cmd) {
  const { url, token, configured } = getKvConfig();
  if (!configured) {
    const err = new Error("Vercel KV / Upstash Redis is not connected (set KV_REST_API_URL & KV_REST_API_TOKEN)");
    err.statusCode = 503;
    throw err;
  }
  const r = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(cmd)
  });
  if (!r.ok) {
    const err = new Error(`KV REST HTTP ${r.status}`);
    err.statusCode = 502;
    throw err;
  }
  const data = await r.json();
  return data.result ?? null;
}

export async function kvGetJson(key) {
  const raw = await kvCommand(["GET", key]);
  if (!raw) return null;
  return typeof raw === "string" ? JSON.parse(raw) : raw;
}

export async function kvSetJson(key, value, ttlSeconds = 0) {
  const serialized = JSON.stringify(value);
  const cmd = ttlSeconds > 0
    ? ["SET", key, serialized, "EX", String(ttlSeconds)]
    : ["SET", key, serialized];
  return kvCommand(cmd);
}
