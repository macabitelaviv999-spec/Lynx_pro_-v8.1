import crypto from "node:crypto";
import { setCors, getOrigin, kvSetJson } from "./_kv.js";

const TTL_90_DAYS = 60 * 60 * 24 * 90;

export default async function handler(req, res) {
  setCors(req, res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method Not Allowed" });

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const targetUrl = String(body.url || "").trim();
    if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
      return res.status(400).json({ error: "Invalid URL" });
    }
    const code = crypto.randomBytes(4).toString("base64url").slice(0, 7);
    const title = String(body.title || "LYNX PRO").slice(0, 60);
    await kvSetJson(`lynx:s:${code}`, { url: targetUrl, title, createdAt: Date.now() }, TTL_90_DAYS);
    return res.status(200).json({ code, shortUrl: `${getOrigin(req)}/s/${code}` });
  } catch (err) {
    return res.status(err.statusCode || 500).json({ error: err.message });
  }
}
