import { setCors, getKvConfig } from "./_kv.js";

export default async function handler(req, res) {
  setCors(req, res);
  if (req.method === "OPTIONS") return res.status(204).end();
  const kv = getKvConfig();
  return res.status(200).json({
    ok: true,
    platform: "vercel",
    version: "8.1",
    kvBound: kv.configured,
    region: process.env.VERCEL_REGION || "local",
    commit: (process.env.VERCEL_GIT_COMMIT_SHA || "dev").slice(0, 7),
    ts: new Date().toISOString()
  });
}
