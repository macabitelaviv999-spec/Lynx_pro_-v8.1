import { setCors, kvGetJson, kvSetJson } from "./_kv.js";

const SNAPSHOT_KEY = "lynx:v8:master_snapshot";

export default async function handler(req, res) {
  setCors(req, res);
  if (req.method === "OPTIONS") return res.status(204).end();

  try {
    if (req.method === "GET") {
      const snapshot = await kvGetJson(SNAPSHOT_KEY);
      return res.status(200).json({ ok: true, snapshot });
    }
    if (req.method === "POST") {
      const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
      const snap = body.payload || body.snapshot;
      if (!snap || typeof snap !== "object") {
        return res.status(400).json({ ok: false, error: "Missing snapshot payload" });
      }
      const syncedAt = Date.now();
      await kvSetJson(SNAPSHOT_KEY, { ...snap, syncedAt });
      return res.status(200).json({ ok: true, syncedAt });
    }
    return res.status(405).json({ ok: false, error: "Method Not Allowed" });
  } catch (err) {
    return res.status(err.statusCode || 500).json({ ok: false, error: err.message });
  }
}
